import express from 'express';
import multer from 'multer';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import OpenAI from 'openai';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { clerkMiddleware, requireAuth, getAuth, clerkClient } from '@clerk/express';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const server = createServer(app);

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Middleware
app.use(express.json());
app.use(express.static(join(__dirname, 'public')));

// Conditional Clerk middleware - only if keys are provided
const publishableKey = process.env.CLERK_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;
const hasClerkKeys = publishableKey && process.env.CLERK_SECRET_KEY;
console.log(`Clerk integration: ${hasClerkKeys ? 'ENABLED' : 'DISABLED (development mode)'}`);

if (hasClerkKeys) {
  console.log(`Using publishable key: ${publishableKey.substring(0, 20)}...`);
  // Set the environment variable that Clerk expects
  process.env.CLERK_PUBLISHABLE_KEY = publishableKey;
  app.use(clerkMiddleware());
}

// File upload handling
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// WebSocket setup
const wss = new WebSocketServer({ server });
let activeConnections = new Set();

wss.on('connection', (ws) => {
  console.log('Client connected');
  activeConnections.add(ws);
  
  ws.on('close', () => {
    console.log('Client disconnected');
    activeConnections.delete(ws);
  });
  
  ws.send(JSON.stringify({ type: 'connected' }));
});

// Broadcast to all connected clients
function broadcast(message) {
  activeConnections.forEach(ws => {
    if (ws.readyState === ws.OPEN) {
      ws.send(JSON.stringify(message));
    }
  });
}

// Commercial API endpoints

// Configuration endpoint to provide Clerk keys to frontend
app.get('/api/config', (req, res) => {
  res.json({
    clerkPublishableKey: publishableKey || null,
    hasClerkIntegration: !!hasClerkKeys
  });
});

// Development middleware for demo mode
const optionalAuth = (req, res, next) => {
  if (!hasClerkKeys) {
    // Development mode - create mock auth and skip Clerk completely
    req.auth = { userId: 'demo-user-1' };
    req.user = { id: 'demo-user-1' };
    return next();
  }
  
  // Even with Clerk keys, allow demo mode for development
  // Check if user is authenticated, if not, create demo auth
  try {
    const auth = getAuth(req);
    if (auth.userId) {
      // User is authenticated
      return next();
    } else {
      // User not authenticated - use demo mode
      req.auth = { userId: 'demo-user-1' };
      req.user = { id: 'demo-user-1' };
      return next();
    }
  } catch (error) {
    // Auth check failed - use demo mode
    req.auth = { userId: 'demo-user-1' };
    req.user = { id: 'demo-user-1' };
    return next();
  }
};

// User endpoint with optional authentication
app.get('/api/user', optionalAuth, async (req, res) => {
  try {
    if (!hasClerkKeys) {
      // Development mode - return demo user
      return res.json({
        id: 'demo-user-1',
        name: 'Demo User',
        email: 'demo@example.com',
        subscriptionTier: 'Professional',
        subscriptionStatus: 'active',
        createdAt: new Date().toISOString(),
        questionsProcessed: 5,
        responsesCopied: 12,
        totalSessions: 3,
        monthlyLimit: 1000
      });
    }

    const { userId } = getAuth(req);
    const user = await clerkClient.users.getUser(userId);
    
    // Get subscription data (this would come from your database)
    // For demo purposes, we'll derive from user metadata or use defaults
    const subscription = user.publicMetadata?.subscription || {
      tier: 'Free',
      status: 'active',
      questionsProcessed: 0,
      responsesCopied: 0,
      totalSessions: 0,
      monthlyLimit: 50
    };
    
    res.json({
      id: user.id,
      name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || 'User',
      email: user.emailAddresses[0]?.emailAddress,
      subscriptionTier: subscription.tier,
      subscriptionStatus: subscription.status,
      createdAt: user.createdAt,
      questionsProcessed: subscription.questionsProcessed,
      responsesCopied: subscription.responsesCopied,
      totalSessions: subscription.totalSessions,
      monthlyLimit: subscription.monthlyLimit
    });
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ error: 'Failed to fetch user data' });
  }
});

// Usage tracking endpoint with optional authentication
app.post('/api/usage/:field', optionalAuth, async (req, res) => {
  try {
    const field = req.params.field;
    
    if (!hasClerkKeys) {
      // Development mode - just log and return
      console.log(`[Demo] Usage tracked: ${field}`);
      return res.json({ success: true, field, count: Math.floor(Math.random() * 20) });
    }

    const { userId } = getAuth(req);
    console.log(`Usage tracked for user ${userId}: ${field}`);
    
    // In production, update user's usage in database
    // await updateUserUsage(userId, field);
    
    // For now, update Clerk user metadata
    const user = await clerkClient.users.getUser(userId);
    const subscription = user.publicMetadata?.subscription || {};
    const updatedSubscription = {
      ...subscription,
      [field]: (subscription[field] || 0) + 1
    };
    
    await clerkClient.users.updateUserMetadata(userId, {
      publicMetadata: {
        ...user.publicMetadata,
        subscription: updatedSubscription
      }
    });
    
    res.json({ success: true, field, count: updatedSubscription[field] });
  } catch (error) {
    console.error('Error tracking usage:', error);
    res.status(500).json({ error: 'Failed to track usage' });
  }
});

// Subscription check middleware with development mode
async function checkSubscriptionLimits(req, res, next) {
  try {
    if (!hasClerkKeys || req.auth.userId === 'demo-user-1') {
      // Development mode or demo user - allow unlimited usage
      req.userSubscription = { tier: 'Professional', questionsProcessed: 5 };
      req.userLimits = { monthlyQuestions: 1000, features: ['basic', 'star-method', 'floating-window'] };
      return next();
    }

    const { userId } = getAuth(req);
    const user = await clerkClient.users.getUser(userId);
    const subscription = user.publicMetadata?.subscription || { tier: 'Free', questionsProcessed: 0 };
    
    // Define limits by tier
    const tierLimits = {
      'Free': { monthlyQuestions: 50, features: ['basic'] },
      'Starter': { monthlyQuestions: 200, features: ['basic', 'star-method'] },
      'Professional': { monthlyQuestions: 1000, features: ['basic', 'star-method', 'floating-window'] },
      'Enterprise': { monthlyQuestions: 5000, features: ['basic', 'star-method', 'floating-window', 'analytics'] }
    };
    
    const userLimits = tierLimits[subscription.tier] || tierLimits['Free'];
    
    if (subscription.questionsProcessed >= userLimits.monthlyQuestions) {
      return res.status(429).json({ 
        error: 'Monthly question limit reached',
        limit: userLimits.monthlyQuestions,
        current: subscription.questionsProcessed,
        tier: subscription.tier,
        upgradeRequired: true
      });
    }
    
    req.userSubscription = subscription;
    req.userLimits = userLimits;
    next();
  } catch (error) {
    console.error('Error checking subscription:', error);
    res.status(500).json({ error: 'Failed to verify subscription' });
  }
}

// Transcription endpoint with optional authentication and subscription checking
app.post('/api/transcribe', optionalAuth, checkSubscriptionLimits, upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No audio file provided' });
    }

    console.log(`[Commercial] Processing ${req.file.size} bytes of audio...`);

    // Skip very small files (likely silence)
    if (req.file.size < 1000) {
      return res.json({ 
        text: '', 
        message: 'Audio too small, likely silence' 
      });
    }

    // Get user profile if provided
    let userProfile = {};
    if (req.body.profile) {
      try {
        userProfile = JSON.parse(req.body.profile);
      } catch (e) {
        console.log('Invalid profile data, using defaults');
      }
    }

    // Transcribe with OpenAI Whisper
    const transcription = await openai.audio.transcriptions.create({
      file: new File([req.file.buffer], 'audio.webm', { type: req.file.mimetype }),
      model: 'whisper-1',
    });

    console.log('Transcription:', transcription.text);

    // Enhanced question detection with STAR method classification
    const text = transcription.text.toLowerCase();
    
    // Behavioral question indicators (STAR method suitable)
    const behavioralIndicators = [
      'tell me about a time',
      'describe a situation',
      'give me an example',
      'share an experience',
      'walk me through',
      'challenge you faced',
      'difficult situation',
      'leadership experience',
      'conflict with',
      'mistake you made',
      'failure',
      'disagreement',
      'under pressure',
      'tight deadline',
      'team project',
      'problem you solved'
    ];
    
    // Technical/general question indicators
    const generalIndicators = [
      'what', 'how', 'why', 'where', 'when',
      'introduce yourself', 'tell me about yourself',
      'strengths', 'weaknesses', 'experience with',
      'can you', 'would you', 'have you', 'do you', 'are you'
    ];
    
    const isBehavioralQuestion = behavioralIndicators.some(indicator => text.includes(indicator));
    const isGeneralQuestion = transcription.text.includes('?') || 
                             generalIndicators.some(indicator => text.includes(indicator)) ||
                             (text.includes('interview') && text.includes('question'));

    if (isBehavioralQuestion || isGeneralQuestion) {
      // Generate AI response
      const aiResponse = await generatePersonalizedResponse(transcription.text, userProfile, isBehavioralQuestion);
      
      res.json({
        success: true,
        text: transcription.text,
        isQuestion: true,
        aiResponse: aiResponse.response,
        questionType: isBehavioralQuestion ? 'behavioral' : 'general'
      });
    } else {
      res.json({
        success: true,
        text: transcription.text,
        isQuestion: false,
        message: 'No clear question detected'
      });
    }

  } catch (error) {
    console.error('Transcription error:', error);
    res.status(500).json({ error: 'Failed to process audio' });
  }
});

// Response generation endpoint with optional authentication
app.post('/api/generate-response', optionalAuth, checkSubscriptionLimits, async (req, res) => {
  try {
    const { question, profile } = req.body;
    
    if (!question) {
      return res.status(400).json({ error: 'Question is required' });
    }

    console.log(`[Commercial] Generating response for: "${question}"`);

    // Detect if behavioral question
    const text = question.toLowerCase();
    const behavioralIndicators = [
      'tell me about a time',
      'describe a situation',
      'give me an example',
      'share an experience',
      'walk me through',
      'challenge you faced',
      'difficult situation',
      'leadership experience',
      'conflict with',
      'mistake you made'
    ];
    
    const isBehavioralQuestion = behavioralIndicators.some(indicator => text.includes(indicator));
    
    // Generate AI response
    const aiResponse = await generatePersonalizedResponse(question, profile || {}, isBehavioralQuestion);
    
    res.json({
      response: aiResponse.response,
      isBehavioral: isBehavioralQuestion,
      questionType: isBehavioralQuestion ? 'behavioral' : 'general'
    });

  } catch (error) {
    console.error('Response generation error:', error);
    res.status(500).json({ error: 'Failed to generate response' });
  }
});

// AI Response Generation Function
async function generatePersonalizedResponse(question, userProfile, isBehavioral = false) {
  try {
    let systemPrompt;
    
    if (isBehavioral) {
      systemPrompt = `You are an interview assistant helping a candidate respond to BEHAVIORAL questions using the STAR method framework.

CANDIDATE PROFILE:
- Company: ${userProfile.company || 'Not specified'}
- Position: ${userProfile.jobTitle || 'Not specified'}
- Industry: ${userProfile.industry || 'Not specified'}
- Experience Level: ${userProfile.experienceLevel || 'mid-level'}
- Response Style: ${userProfile.responseStyle || 'professional'}

BACKGROUND: ${userProfile.userBackground || 'Not specified'}

JOB REQUIREMENTS: ${userProfile.jobDescription || 'Not specified'}

STAR METHOD INSTRUCTIONS:
Structure your response using the STAR framework:

**Situation**: Set the context with a specific example from the candidate's background
**Task**: Describe the challenge or responsibility that needed to be addressed
**Action**: Explain the specific steps taken to address the situation
**Result**: Share the positive outcome and what was learned/achieved

RESPONSE GUIDELINES:
- Use the candidate's actual background to create realistic scenarios
- Make the situation relevant to the target company and role
- Include quantifiable results when possible (metrics, percentages, achievements)
- Keep the response conversational but structured
- Ensure the example demonstrates skills relevant to the job requirements
- Use ${userProfile.responseStyle || 'professional'} tone throughout`;
    } else {
      systemPrompt = `You are an interview assistant helping a candidate respond to GENERAL interview questions.

CANDIDATE PROFILE:
- Company: ${userProfile.company || 'Not specified'}
- Position: ${userProfile.jobTitle || 'Not specified'}
- Industry: ${userProfile.industry || 'Not specified'}
- Experience Level: ${userProfile.experienceLevel || 'mid-level'}
- Response Style: ${userProfile.responseStyle || 'professional'}

BACKGROUND: ${userProfile.userBackground || 'Not specified'}

JOB REQUIREMENTS: ${userProfile.jobDescription || 'Not specified'}

INSTRUCTIONS:
- Tailor the response to match the specific company and role
- Reference relevant experience from the candidate's background
- Align with the job requirements when applicable
- Use the requested response style (${userProfile.responseStyle || 'professional'})
- Keep responses concise but impactful (2-3 sentences)
- Be confident and specific
- For "tell me about yourself" questions, structure as: current role → relevant experience → why interested in this position`;
    }

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o', // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: 'system',
          content: systemPrompt
        },
        {
          role: 'user',
          content: question
        }
      ],
      max_tokens: 250
    });

    return {
      response: completion.choices[0].message.content,
      questionType: isBehavioral ? 'behavioral' : 'general'
    };

  } catch (error) {
    console.error('AI response generation error:', error);
    throw error;
  }
}

// Legacy transcription endpoint (keeping for compatibility)
app.post('/transcribe', upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No audio file provided' });
    }

    console.log(`Processing ${req.file.size} bytes of audio...`);

    // Skip very small files (likely silence)
    if (req.file.size < 1000) {
      return res.json({ 
        success: true, 
        text: '', 
        message: 'Audio too small, likely silence' 
      });
    }

    // Get user profile if provided
    let userProfile = {};
    if (req.body.profile) {
      try {
        userProfile = JSON.parse(req.body.profile);
      } catch (e) {
        console.log('Invalid profile data, using defaults');
      }
    }

    // Transcribe with OpenAI Whisper
    const transcription = await openai.audio.transcriptions.create({
      file: new File([req.file.buffer], 'audio.webm', { type: req.file.mimetype }),
      model: 'whisper-1',
    });

    console.log('Transcription:', transcription.text);

    // Enhanced question detection with STAR method classification
    const text = transcription.text.toLowerCase();
    
    // Behavioral question indicators (STAR method suitable)
    const behavioralIndicators = [
      'tell me about a time',
      'describe a situation',
      'give me an example',
      'share an experience',
      'walk me through',
      'challenge you faced',
      'difficult situation',
      'leadership experience',
      'conflict with',
      'mistake you made',
      'failure',
      'disagreement',
      'under pressure',
      'tight deadline',
      'team project',
      'problem you solved'
    ];
    
    // Technical/general question indicators
    const generalIndicators = [
      'what', 'how', 'why', 'where', 'when',
      'introduce yourself', 'tell me about yourself',
      'strengths', 'weaknesses', 'experience with',
      'can you', 'would you', 'have you', 'do you', 'are you'
    ];
    
    const isBehavioralQuestion = behavioralIndicators.some(indicator => text.includes(indicator));
    const isGeneralQuestion = transcription.text.includes('?') || 
                             generalIndicators.some(indicator => text.includes(indicator)) ||
                             (text.includes('interview') && text.includes('question'));
    
    const isQuestion = isBehavioralQuestion || isGeneralQuestion;
    const questionType = isBehavioralQuestion ? 'behavioral' : 'general';

    let aiResponse = null;

    // Generate personalized AI response if it's a question
    if (isQuestion && transcription.text.trim().length > 10) {
      console.log('Question detected, generating personalized AI response...');
      
      // Build personalized system prompt with STAR method integration
      let systemPrompt;
      
      if (questionType === 'behavioral') {
        systemPrompt = `You are an interview assistant helping a candidate respond to BEHAVIORAL questions using the STAR method framework.

CANDIDATE PROFILE:
- Company: ${userProfile.company || 'Not specified'}
- Position: ${userProfile.jobTitle || 'Not specified'}
- Industry: ${userProfile.industry || 'Not specified'}
- Experience Level: ${userProfile.experienceLevel || 'mid-level'}
- Response Style: ${userProfile.responseStyle || 'professional'}

BACKGROUND: ${userProfile.userBackground || 'Not specified'}

JOB REQUIREMENTS: ${userProfile.jobDescription || 'Not specified'}

STAR METHOD INSTRUCTIONS:
Structure your response using the STAR framework:

**Situation**: Set the context with a specific example from the candidate's background
**Task**: Describe the challenge or responsibility that needed to be addressed
**Action**: Explain the specific steps taken to address the situation
**Result**: Share the positive outcome and what was learned/achieved

RESPONSE GUIDELINES:
- Use the candidate's actual background to create realistic scenarios
- Make the situation relevant to the target company and role
- Include quantifiable results when possible (metrics, percentages, achievements)
- Keep the response conversational but structured
- Ensure the example demonstrates skills relevant to the job requirements
- Use ${userProfile.responseStyle || 'professional'} tone throughout`;
      } else {
        systemPrompt = `You are an interview assistant helping a candidate respond to GENERAL interview questions.

CANDIDATE PROFILE:
- Company: ${userProfile.company || 'Not specified'}
- Position: ${userProfile.jobTitle || 'Not specified'}
- Industry: ${userProfile.industry || 'Not specified'}
- Experience Level: ${userProfile.experienceLevel || 'mid-level'}
- Response Style: ${userProfile.responseStyle || 'professional'}

BACKGROUND: ${userProfile.userBackground || 'Not specified'}

JOB REQUIREMENTS: ${userProfile.jobDescription || 'Not specified'}

INSTRUCTIONS:
- Tailor the response to match the specific company and role
- Reference relevant experience from the candidate's background
- Align with the job requirements when applicable
- Use the requested response style (${userProfile.responseStyle || 'professional'})
- Keep responses concise but impactful (2-3 sentences)
- Be confident and specific
- For "tell me about yourself" questions, structure as: current role → relevant experience → why interested in this position`;
      }

      const completion = await openai.chat.completions.create({
        model: 'gpt-4o', // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: 'system',
            content: systemPrompt
          },
          {
            role: 'user',
            content: transcription.text
          }
        ],
        max_tokens: 250
      });

      aiResponse = completion.choices[0].message.content;
      console.log('Personalized AI Response generated');

      // Broadcast to connected clients with question type
      broadcast({
        type: 'question',
        question: transcription.text,
        response: aiResponse,
        questionType: questionType,
        profile: userProfile
      });
    }

    res.json({
      success: true,
      text: transcription.text,
      isQuestion,
      questionType: questionType,
      aiResponse
    });

  } catch (error) {
    console.error('Transcription error:', error);
    res.status(500).json({ 
      error: 'Transcription failed',
      details: error.message 
    });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Simple Interview Assistant running on port ${PORT}`);
  console.log(`📱 Open http://localhost:${PORT} to start`);
});