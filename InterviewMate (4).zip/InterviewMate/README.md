# Simple Interview Assistant

A clean, minimal Node.js application for real-time interview assistance using AI.

## Features

- **Tab Audio Capture**: Capture audio from interview tabs (Zoom, Teams, Meet)
- **Real-time Transcription**: OpenAI Whisper API integration
- **AI Response Generation**: GPT-4o powered interview responses
- **Live Updates**: WebSocket for real-time question/response display
- **Simple UI**: Single-page web interface

## Setup

1. **Install dependencies**:
```bash
cd simple-app
npm install
```

2. **Set OpenAI API key**:
```bash
export OPENAI_API_KEY="your-openai-api-key-here"
```

3. **Start the server**:
```bash
npm start
# or for development with auto-restart:
npm run dev
```

4. **Open in browser**:
```
http://localhost:3000
```

## Usage

1. Click "Start Tab Audio Capture"
2. Select the tab with your interview (Zoom, Teams, etc.)
3. The app will automatically:
   - Record 5-second audio chunks
   - Transcribe speech using Whisper
   - Detect interview questions
   - Generate AI responses using GPT-4o
4. Copy suggested responses to use in your interview

## Architecture

**Simple & Clean:**
- `server.js` - Single Node.js file with Express server
- `public/index.html` - Single-page frontend with vanilla JavaScript
- WebSocket for real-time updates
- Direct OpenAI API integration

**No Complexity:**
- No database required
- No complex state management
- No build process needed
- Minimal dependencies

## API Endpoints

- `POST /transcribe` - Upload audio for transcription
- `GET /health` - Health check
- WebSocket on `/` - Real-time updates

## Environment Variables

- `OPENAI_API_KEY` - Your OpenAI API key (required)
- `PORT` - Server port (default: 3000)

## How It Works

1. **Audio Capture**: Uses `getDisplayMedia()` to capture tab audio
2. **Recording**: 5-second chunks sent to server
3. **Transcription**: OpenAI Whisper API converts audio to text
4. **Question Detection**: Simple text analysis for interview questions
5. **AI Response**: GPT-4o generates professional interview responses
6. **Real-time Updates**: WebSocket broadcasts questions/responses to UI

This is a minimal, focused implementation that does exactly what you need without unnecessary complexity.