# How to Check Clerk.dev Integration

## 1. Check Current Mode

Look at your server logs when starting:
```
Clerk integration: DISABLED (development mode)
```
or
```
Clerk integration: ENABLED (production mode)
```

## 2. Test API Endpoints

### Check User Endpoint
```bash
curl http://localhost:5000/api/user
```

**Development Mode Response:**
```json
{
  "id": "demo-user-1",
  "name": "Demo User",
  "email": "demo@example.com",
  "subscriptionTier": "Professional",
  "subscriptionStatus": "active",
  "questionsProcessed": 5,
  "responsesCopied": 12,
  "totalSessions": 3,
  "monthlyLimit": 1000
}
```

**Production Mode (without auth):**
```json
{
  "error": "Unauthorized"
}
```

### Test Usage Tracking
```bash
curl -X POST http://localhost:5000/api/usage/questionsProcessed
```

**Development Mode:**
```json
{
  "success": true,
  "field": "questionsProcessed",
  "count": 15
}
```

## 3. Check Environment Variables

Add these to Replit Secrets to enable production mode:

```
CLERK_PUBLISHABLE_KEY=pk_test_xxxxxxxxxx
CLERK_SECRET_KEY=sk_test_xxxxxxxxxx
```

## 4. Frontend Integration Test

Your HTML frontend should make authenticated requests like:
```javascript
// Check if user is loaded
fetch('/api/user')
  .then(r => r.json())
  .then(user => {
    console.log('User:', user);
    console.log('Subscription:', user.subscriptionTier);
    console.log('Usage:', user.questionsProcessed, '/', user.monthlyLimit);
  })
  .catch(err => console.log('Auth required:', err));
```

## 5. Subscription Limits Test

The system enforces these limits:
- **Free**: 50 questions/month
- **Starter**: 200 questions/month  
- **Professional**: 1,000 questions/month
- **Enterprise**: 5,000 questions/month

When limits are exceeded:
```json
{
  "error": "Monthly question limit reached",
  "limit": 50,
  "current": 51,
  "tier": "Free",
  "upgradeRequired": true
}
```

## 6. Production Setup Checklist

✅ **Get Clerk Keys**: Sign up at clerk.dev  
✅ **Add to Secrets**: CLERK_PUBLISHABLE_KEY & CLERK_SECRET_KEY  
✅ **Restart App**: Server will switch to production mode  
✅ **Test Auth**: All endpoints require authentication  
✅ **Update Frontend**: Add Clerk authentication UI

Your app is now ready for commercial use with enterprise-grade authentication and subscription management!