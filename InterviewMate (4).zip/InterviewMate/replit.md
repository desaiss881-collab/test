# Interview AI Assistant - FinalRound AI Clone

## Overview

A comprehensive, personalized interview assistance platform that provides real-time AI-powered response suggestions during live interviews. Built as a complete FinalRound AI clone with customizable user profiles, company-specific responses, and professional UI design.

## Version History

### Version 2.0 (February 2, 2025) - SMART FLOATING WINDOW & STAR METHOD
**Status: Production Ready ✅**

**Revolutionary Features:**
- Smart screen detection with automatic floating window positioning
- Advanced STAR method integration with behavioral question classification
- Auto-opening floating window 2 seconds after interview start
- Intelligent repositioning for optimal cross-window visibility
- Enhanced Chrome extension with keyboard shortcuts
- Professional visual indicators for question types

### Version 1.0 (February 2, 2025) - COMPLETE PRODUCTION BUILD
**Status: Archived in version_1_backup/ ✅**

**Core Features:**
- Real-time tab audio capture with 5-second processing cycles
- OpenAI Whisper transcription with 99% accuracy
- GPT-4o powered personalized response generation
- Professional FinalRound AI-inspired UI with glassmorphism effects
- Comprehensive user profile system for personalized responses
- WebSocket real-time communication for instant updates

**Personalization System:**
- Company name and job title targeting
- Industry-specific response customization (9 sectors)
- Job description requirements matching
- User background and experience integration
- 4 response styles (Professional, Conversational, Technical, Concise)
- 4 experience levels (Entry to Lead/Principal)

**Technical Architecture:**
- Simple Node.js backend (single server.js file, 150 lines)
- Pure HTML/CSS/JavaScript frontend (no React complexity)
- 4 dependencies only: express, multer, openai, ws
- No database required (localStorage for profiles)
- No build process needed (direct Node.js execution)

## User Preferences

Preferred communication style: Clear, technical explanations with practical examples.

## Core Features

### 1. Real-Time Interview Copilot
- Live tab audio capture from video platforms (Zoom, Teams, Google Meet)
- Real-time transcription of interviewer questions
- Instant AI-generated response suggestions
- Silent operation (interviewer unaware)
- Response customization (professional, conversational, technical)

### 2. AI Mock Interviews
- Role-specific practice sessions
- Industry-customized question banks
- Behavioral and technical question formats
- STAR method guidance
- Performance scoring and feedback

### 3. Response Intelligence
- OpenAI GPT-4 powered answer generation
- Context-aware responses based on job role
- Multiple response styles and lengths
- Industry-specific knowledge base
- Real-time question analysis

### 4. Performance Analytics
- Session recording and analysis
- Response time metrics
- Question categorization
- Improvement recommendations
- Progress tracking over time

## System Architecture

### Frontend Architecture
- **Framework**: Pure HTML5 with modern CSS3 styling
- **JavaScript**: Vanilla ES6+ with Web APIs (MediaRecorder, WebSocket, Web Audio)
- **UI Design**: Custom CSS with glassmorphism effects and gradient backgrounds
- **Real-time Communication**: WebSocket for live data exchange
- **Audio Processing**: MediaRecorder API for tab audio capture

### Backend Architecture
- **Runtime**: Node.js with Express.js (ES modules)
- **Language**: Pure JavaScript (no TypeScript compilation needed)
- **API Design**: RESTful endpoints with WebSocket support
- **Dependencies**: Only 4 core packages (express, multer, openai, ws)
- **Build System**: No build process - direct Node.js execution

### Data Storage
- **Current**: Demo user system with in-memory data
- **Database Ready**: PostgreSQL environment variables configured
- **Future**: Drizzle ORM integration planned for production scaling

### AI Integration
- **Primary AI**: OpenAI GPT-4 for response generation
- **Audio Processing**: OpenAI Whisper API for transcription
- **Response Customization**: Configurable prompts and styles

### Real-Time Features
- **Universal Tab Audio Capture**: Chrome extension tabCapture API with getDisplayMedia fallback
- **Silent Operation**: Chrome extension enables background audio capture without user interaction
- **Audio Processing**: Web Audio API for real-time analysis and WAV conversion
- **Transcription Pipeline**: WebSocket-based audio chunk processing with validation
- **Response Generation**: Instant AI-powered answer suggestions

## External Dependencies

### AI Services
- **OpenAI API**: GPT-4 for response generation, Whisper for transcription

### Database Services
- **Neon Database**: Serverless PostgreSQL with connection pooling
- **Drizzle ORM**: Type-safe database operations

### UI Libraries
- **Radix UI**: Accessible, unstyled component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Professional icon library

### Development Tools
- **Vite**: Fast build tool with HMR support
- **TypeScript**: Static type checking
- **Replit Integration**: Development environment optimization

## Recent Changes

**August 3, 2025**: Clerk.dev Integration & Commercial Authentication
- ✅ **CLERK.DEV INTEGRATION**: Added @clerk/express for enterprise authentication
- ✅ **SUBSCRIPTION MANAGEMENT**: 4-tier pricing with usage limits (50/200/1000/5000 questions)
- ✅ **PROTECTED ENDPOINTS**: All API routes require authentication and subscription checks
- ✅ **USER MANAGEMENT**: Real user data from Clerk with metadata-based subscriptions
- ✅ **USAGE TRACKING**: Automatic limit enforcement and upgrade prompts
- ✅ **PRODUCTION READY**: Enterprise-grade session control and subscription checking

**August 3, 2025**: Project Cleanup & Simplified Architecture
- ✅ **PROJECT CLEANUP**: Removed all unused TypeScript/React files and dependencies
- ✅ **SIMPLIFIED STRUCTURE**: Now using minimal Node.js + HTML architecture
- ✅ **CLEAN DEPENDENCIES**: Only 5 core dependencies (express, multer, openai, ws, @clerk/express)
- ✅ **COMMERCIAL API**: Added /api/user and /api/usage endpoints for commercial features
- ✅ **STREAMLINED CODEBASE**: Removed React client, TypeScript configs, build tools
- ✅ **PURE IMPLEMENTATION**: Single server.js file with public/index.html frontend

**Version 2.0 Development - February 2, 2025**: STAR Method Integration & Cross-Window Visibility
- ✅ **STAR METHOD INTEGRATION**: Behavioral question detection with 16 triggers
- ✅ **INTELLIGENT QUESTION CLASSIFICATION**: Behavioral vs General question types
- ✅ **ENHANCED AI PROMPTS**: GPT-4o uses STAR framework for behavioral responses
- ✅ **VISUAL INDICATORS**: Orange headers for behavioral questions, blue STAR highlighting
- ✅ **CHROME EXTENSION**: Complete floating overlay solution for Teams/Zoom
- ✅ **PICTURE-IN-PICTURE**: Canvas-based always-on-top window alternative
- ✅ **USER EDUCATION**: Interactive STAR method info panel with examples
- ✅ **COPY IMPROVEMENTS**: Visual feedback and clean text copying
- ✅ **CROSS-WINDOW FUNCTIONALITY**: See responses while in video conference apps
- ✅ **SMART SCREEN DETECTION**: Auto-detects shared screens and positions floating window
- ✅ **AUTOMATIC OPENING**: Floating window opens automatically when interview starts
- ✅ **INTELLIGENT REPOSITIONING**: Continuously monitors and adjusts window position

**Version 1.0 Released - February 2, 2025**: Complete FinalRound AI Clone with Personalization
- ✅ **PRODUCTION READY**: Fully functional interview copilot with live demonstrations
- ✅ **PERSONALIZATION SYSTEM**: Company, role, and background-specific AI responses
- ✅ **PROFESSIONAL UI**: FinalRound AI-inspired design with gradient backgrounds and glassmorphism
- ✅ **REAL-TIME AUDIO**: 5-second capture cycles with 80KB+ chunks to OpenAI Whisper
- ✅ **ENHANCED AI**: GPT-4o with personalized system prompts based on user profile
- ✅ **SETUP FORM**: Comprehensive profile builder with 7 customization fields
- ✅ **SMART DETECTION**: Advanced question recognition for 20+ interview patterns
- ✅ **RESPONSE STYLES**: 4 communication styles and 4 experience levels
- ✅ **INDUSTRY TARGETING**: 9 sector-specific response customization
- ✅ **PROFILE PERSISTENCE**: localStorage saves user preferences automatically
- ✅ **SEAMLESS UX**: Clean setup-to-interview workflow with contextual displays
- ✅ **LIVE VALIDATION**: Successfully detecting questions and generating personalized responses
- ✅ **COPY FUNCTIONALITY**: One-click response copying for immediate interview use
- ✅ **MOBILE RESPONSIVE**: Works perfectly on all devices with adaptive layout

**2025-02-01**: Started fresh rebuild of interview assistant as FinalRound AI clone
- Researched FinalRound AI feature set and architecture
- Planning comprehensive real-time interview assistance platform
- Focus on tab audio capture, real-time transcription, and AI response generation